const express = require('express');
const mongoose = require('mongoose');
const AuthRoutes = require("./Router/AuthRoutes")
const cookieParser = require("cookie-parser")
const {requireAuth , checkUser} = require("./Middleware/AuthMiddleware")

const app = express();

// middleware
app.use(express.static('public'));
app.use(express.json());
app.use(cookieParser())

// view engine
app.set('view engine', 'ejs');

// database connection
const dbURI = 'mongodb+srv://JWTPASSWORD:JWTPASSWORD@cluster0.v2ihv2f.mongodb.net/?retryWrites=true&w=majority';
mongoose.connect(dbURI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then((result) => app.listen(3000))
  .catch((err) => console.log(err));

// routes
app.get('*', checkUser);
app.get('/', (req, res) => res.render('home'));
app.get('/smoothies',requireAuth, (req, res) => res.render('smoothies'));

app.use(AuthRoutes);

// cookies

// app.get("/get-cookies",(req,res)=>{
//   res.cookie("newUser" , true,{maxAge:1000*60*60*24, secure:true})
//  res.cookie("bhas",false)

//   res.send("you got the cookie")
// })

// app.get("/read-cookies",(req,res)=>{
//   const cookie = req.cookies

// console.log(cookie)
//   res.json(cookie)
// })